namespace P03_FootballBetting.Data.Configurations
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=.;Database=FootballBetting;Integrated Security=True";
    }
}