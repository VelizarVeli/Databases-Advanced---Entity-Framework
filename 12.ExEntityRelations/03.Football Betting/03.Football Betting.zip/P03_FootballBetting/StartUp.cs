namespace P03_FootballBetting
{
    using System;

    public class Startup
    {
        public static void Main()
        {
            
        }
    }
}