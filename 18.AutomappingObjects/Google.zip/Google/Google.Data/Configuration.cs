﻿namespace Google.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-8ECROG0\SQLEXPRESS;Database=Google;Integrated Security=True";
    }
}
