﻿using System;

namespace Google.Services
{
    public interface IDbInitializerService
    {
        void InitializeDatabase();
    }
}
